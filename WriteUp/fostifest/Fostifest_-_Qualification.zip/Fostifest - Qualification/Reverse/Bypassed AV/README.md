# Bypassed AV [500 pts]

**Category:** Reverse
**Solves:** 0

## Description
>Attacker telah mengeksekusi kode dan mencuri flag dari sistem, tetapi ia menggunakan cara yang tidak umum untuk membypass deteksi antivirus, dapatkah kamu menganalisa dan mengembalikan kembali flagnya?

#### Hint 

## Solution

## Flag

