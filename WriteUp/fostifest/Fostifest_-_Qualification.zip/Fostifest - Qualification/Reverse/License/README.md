# License [464 pts]

**Category:** Reverse
**Solves:** 4

## Description
>`nc 103.250.10.198 31337`

#### Hint 

## Solution

## Flag

