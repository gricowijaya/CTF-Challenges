# PyWN [356 pts]

**Category:** Pwn
**Solves:** 7

## Description
>`nc 103.250.10.198 10011`

#### Hint 

## Solution

## Flag

