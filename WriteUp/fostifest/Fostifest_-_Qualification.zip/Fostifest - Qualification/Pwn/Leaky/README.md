# Leaky [496 pts]

**Category:** Pwn
**Solves:** 2

## Description
>`nc 103.13.206.173 10003`

#### Hint 

## Solution

## Flag

