# oldnote [500 pts]

**Category:** Pwn
**Solves:** 1

## Description
>`nc 103.13.206.173 10001`

#### Hint 

## Solution

## Flag

