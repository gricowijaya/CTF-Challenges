# Initial Access Backdoor [212 pts]

**Category:** Forensic
**Solves:** 9

## Description
>Full path backdoor for initial access in system \r\nFlag: `Fostifest{%s}`\r\nExample: `Fostifest{/path/path/path/file}`

#### Hint
* how is it possible that someone without access can enter our server ?\n* Malware in system path, not public url\nexample: `/home/xxx/xxx/xxx` or `/var/xxx/xxx`\n* from where attacker execute the command ?

## Solution

## Flag

