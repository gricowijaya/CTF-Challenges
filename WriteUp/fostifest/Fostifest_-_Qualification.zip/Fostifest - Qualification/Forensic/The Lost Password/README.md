# The Lost Password [460 pts]

**Category:** Forensic
**Solves:** 4

## Description
>It looks like the attacker has changed the password from the admin which is used to login to the admin dashboard on web port 80. Look for the password of the admin before changed

#### Hint
* Sepertinya hekerz menyerang dari salah satu service web untuk mendapatkan password admin sebelumnya

## Solution

## Flag

