# Repo of PE File [388 pts]

**Category:** Forensic
**Solves:** 6

## Description
>Original Repository of files used for privilege escalation\r\nFormat Flag: `Fostifest{url}`

#### Hint 

## Solution

## Flag

