# The Root [500 pts]

**Category:** Forensic
**Solves:** 1

## Description
>Woopzzz! Looks like hackerz has a backdoor that is used to call the root user, look for full path of that file\r\nFormat Flag: `Fostifest{/path/path/path/file}`

#### Hint 

## Solution

## Flag

