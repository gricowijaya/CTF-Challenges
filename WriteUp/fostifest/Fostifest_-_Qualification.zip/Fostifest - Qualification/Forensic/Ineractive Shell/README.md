# Ineractive Shell [338 pts]

**Category:** Forensic
**Solves:** 7

## Description
>IP and Port attacker to get interactive shell\r\nFormat Flag: `Fostifest{IP:Port}`\r\n\r\nExample: `Fostifest{x.x.x.x:xxxx}`

#### Hint 

## Solution

## Flag

