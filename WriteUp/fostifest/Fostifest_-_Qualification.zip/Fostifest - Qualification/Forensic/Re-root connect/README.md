# Re-root connect [482 pts]

**Category:** Forensic
**Solves:** 3

## Description
>Looks like hackerz keeps one more backdoor to get root access, looks like he can connect to the machine every minute!\r\nFind the full path of this backdoor and the destination IP Port used by the attacker\r\nFormat Flag: `Fostifest{/full/path/file:IP:Port}`

#### Hint 

## Solution

## Flag

