# The Attacker [50 pts]

**Category:** Forensic
**Solves:** 11

## Description
>Server Fosti yang memiliki beberapa service yang berjalan di dalamnya telah dimasuki oleh hekerz pada sekitar tanggal 20-25 september, diduga kuat hekerz tersebut telah menanamkan banyak backdoor di dalam server. Tugas kalian adalah menyelidiki dan menginvestigasi pada server Fosti agar semua jejak hekerz tersebut terlacak\r\n\r\nPada challenge ini carilah IP dari si Attacker alias Hekerz\r\nFormat Flag: `Fostifest{IP-Attacker}`

#### Hint
* Password Zip ada di bonus\n* Reset password untuk masuk ke VM

## Solution

## Flag

