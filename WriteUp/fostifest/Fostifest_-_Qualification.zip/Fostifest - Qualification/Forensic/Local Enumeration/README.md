# Local Enumeration [460 pts]

**Category:** Forensic
**Solves:** 4

## Description
>File used by the attacker to enumerate the local system to perform information gathering full path\r\n\r\nFormat Flag: `Fostifest{/path/path/path/file}`

#### Hint 

## Solution

## Flag

