# Privilege Escalation [388 pts]

**Category:** Forensic
**Solves:** 6

## Description
>CVE and full path file that used by attackers to perform privilege escalation\r\nFormat Flag: `Fostifest{CVE-XXXX-XXXX:/path/path/path/file}`

#### Hint 

## Solution

## Flag

