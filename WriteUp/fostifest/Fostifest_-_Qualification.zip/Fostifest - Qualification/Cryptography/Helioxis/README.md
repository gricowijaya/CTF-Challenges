# Helioxis [500 pts]

**Category:** Cryptography
**Solves:** 0

## Description
>Be careful, fragile things, handle with care

#### Hint 

## Solution

## Flag

