# Izanami [500 pts]

**Category:** Cryptography
**Solves:** 0

## Description
>(n, n) threshold encryption v2.0

#### Hint
* n can be factored with ECM

## Solution

## Flag

