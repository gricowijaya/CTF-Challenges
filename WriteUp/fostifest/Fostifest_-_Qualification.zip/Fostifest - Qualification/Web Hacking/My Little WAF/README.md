# My Little WAF [484 pts]

**Category:** Web Hacking
**Solves:** 3

## Description
>Url: http://103.250.10.198:10001/\r\n\r\nFilternya di luar nalar cooyyyy.\r\nTapi tentu saja tidak untuk hacker terbaik putra bangsa yang bahkan bisa mengehek nasa

#### Hint 

## Solution

## Flag

