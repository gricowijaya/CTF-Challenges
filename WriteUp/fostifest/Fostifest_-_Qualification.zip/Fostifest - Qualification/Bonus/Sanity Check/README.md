# Sanity Check [100 pts]

**Category:** Bonus
**Solves:** 21

## Description
>`Flag: Fostifest{Anjazzz_Kelazzzzzzzz}`

#### Hint 

## Solution

## Flag

