# Fosti Server Password [100 pts]

**Category:** Bonus
**Solves:** 20

## Description
>Gunakan password dibawah ini untuk membuka file Zip Fosti Server\r\nPassword: `fostifest_d52f925a44fe265dcf678e8da09aab79`\r\n\r\nFlag chall ini: `Fostifest{%s}` %password

#### Hint 

## Solution

## Flag

