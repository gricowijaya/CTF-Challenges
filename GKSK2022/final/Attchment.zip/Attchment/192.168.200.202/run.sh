socat tcp-listen:3000,reuseaddr,fork exec:/home/ubuntu/src/chall.py &
